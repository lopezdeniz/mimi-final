<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="utf-8">
    <title>Доставка суши, роллов и пиццы Кострома - МиМи суши</title>
    <link href="https://lk.easynetshop.ru/frontend/v5/ens-4e44247d.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style2.css">
    <link rel="stylesheet" href="css/style3.css">
    <link rel="stylesheet" href="css/media-config.css">
    <script type="text/javascript" src="jquery-3.6.3.min.js"></script>
    <link rel="stylesheet" href="css/font-awesome-4.7.0/css/font-awesome.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Бесплатная доставка суши, роллов и пиццы на дом — вкусно, дешево, быстро, заказ онлайн или по телефону. Мы готовим только из свежих продуктов высокого качества.">
    <meta name="keywords" content="доставка пиццы, заказ пиццы, пицца круглосуточно, суши, роллы, доставка суши, заказ суши, суши круглосуточно, доставка роллов, заказ роллов, роллы круглосуточно">
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();
   for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
   k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(92807488, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true,
        ecommerce:"dataLayer"
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/92807488" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</head>

<body>
<?php
include('nav.php')
?>

        <section class="fon-back">
        <div class="mytext-centr"><h2 class="menu-centr">ПОКЕ</h2></div>






        <div class="cards2" >


        <!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/poke-krevet-card.png"alt="">
  <div class="card__label2">320&#8381</div>
</div>
  <p class="text">
  Рис паровой, Креветки для суши, Огурцы, Черри, Чука, Фасоль Эдамамэ, Харумаки на Харбинский, Нори, Кунжут. На доставку + соевый соус
 (320гр)</p>
  <h2 class="text2"><span style="font-weight:bold">ПОКЕ С КРЕВЕТКАМИ</span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307649">Добавить</a>
  </div>
</div>

<!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/poke-losos-card.png"alt="">
  <div class="card__label2">330&#8381</div>
</div>
  <p class="text">Рис паровой, Лосось для суши, Чука, Огурцы, Черри, Фасоль Эдамамэ, Харумаки на Харбинский, Нори, Кунжут. На доставку + соевый соус (320гр.)</p>
  <h2 class="text2"><span style="font-weight:bold">ПОКЕ С ЛОСОСЕМ</span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307650">Добавить</a>
  </div>
</div>














    
                  



























      



















             
    </div>
        </section>
        
        <br> 
<br> 
    </main>

    <script src="js/script.js"></script>
    <script defer src="https://lk.easynetshop.ru/frontend/v5/ens-4e44247d.js"></script>
    <style>.powered {display:none}</style>
    
    
</body>

</html>