<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="utf-8">
    <title>Доставка суши, роллов и пиццы Кострома - МиМи суши</title>
    <link href="https://lk.easynetshop.ru/frontend/v5/ens-4e44247d.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style2.css">
    <link rel="stylesheet" href="css/style3.css">
    <link rel="stylesheet" href="css/media-config.css">
    <script type="text/javascript" src="jquery-3.6.3.min.js"></script>
    <link rel="stylesheet" href="css/font-awesome-4.7.0/css/font-awesome.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Бесплатная доставка суши, роллов и пиццы на дом — вкусно, дешево, быстро, заказ онлайн или по телефону. Мы готовим только из свежих продуктов высокого качества.">
    <meta name="keywords" content="доставка пиццы, заказ пиццы, пицца круглосуточно, суши, роллы, доставка суши, заказ суши, суши круглосуточно, доставка роллов, заказ роллов, роллы круглосуточно">
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();
   for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
   k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(92807488, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true,
        ecommerce:"dataLayer"
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/92807488" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</head>

<body>
<?php
include('nav.php')
?>

        <section class="fon-back">
        <div class="mytext-centr"><h2 class="menu-centr">ПИЦЦА</h2></div>






        <div class="cards2" >


        <!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/piperoni-card.png"alt="">
  <div class="card__label2">500&#8381</div>
</div>
  <p class="text">
  Соус, сыр моцарелла, пепперони, базилик (540гр.)</p>
  <h2 class="text2"><span style="font-weight:bold">Пепперони (30см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307965">Добавить</a>
  </div>
</div>

        <!-- Карточка товара 1 -->
        <div class="block">
    <div class="card-price">
  <img src="./img/piperoni-card.png"alt="">
  <div class="card__label2">550&#8381</div>
</div>
  <p class="text">
  Соус, сыр моцарелла, пепперони, базилик (640гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Пепперони (35см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307966">Добавить</a>
  </div>
</div>

 <!-- Карточка товара 1 -->
 <div class="block">
    <div class="card-price">
  <img src="./img/nej-card.png"alt="">
  <div class="card__label2">550&#8381</div>
</div>
  <p class="text">
  Соус, ветчина, шампиньоны, базилик  (490гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Нежность (30см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307967">Добавить</a>
  </div>
</div>

 <!-- Карточка товара 1 -->
 <div class="block">
    <div class="card-price">
  <img src="./img/nej-card.png"alt="">
  <div class="card__label2">600&#8381</div>
</div>
  <p class="text">
  Соус, ветчина, шампиньоны, базилик  (590гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Нежность (35см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307968">Добавить</a>
  </div>
</div>

 <!-- Карточка товара 1 -->
 <div class="block">
    <div class="card-price">
  <img src="./img/margarita.png"alt="">
  <div class="card__label2">400&#8381</div>
</div>
  <p class="text">
  Сыр моцарелла, томаты, соус, базилик (493гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Маргарита (30см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307969">Добавить</a>
  </div>
</div>


 <!-- Карточка товара 1 -->
 <div class="block">
    <div class="card-price">
  <img src="./img/margarita.png"alt="">
  <div class="card__label2">450&#8381</div>
</div>
  <p class="text">
  Сыр моцарелла, томаты, соус, базилик (593гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Маргарита (35см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307970">Добавить</a>
  </div>
</div>

 <!-- Карточка товара 1 -->
 <div class="block">
    <div class="card-price">
  <img src="./img/4syra.png"alt="">
  <div class="card__label2">550&#8381</div>
</div>
  <p class="text">
  Сыр моцарелла, соус, сыр пармезан, сыр гауда, сыр дорблю  (550гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Четыре сыра (30см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307971">Добавить</a>
  </div>
</div>


<!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/4syra.png"alt="">
  <div class="card__label2">600&#8381</div>
</div>
  <p class="text">
  Сыр моцарелла, соус, сыр пармезан, сыр гауда, сыр дорблю  (650гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Четыре сыра (35см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307972">Добавить</a>
  </div>
</div>



 <!-- Карточка товара 1 -->
 <div class="block">
    <div class="card-price">
  <img src="./img/mimi-card.png"alt="">
  <div class="card__label2">649&#8381</div>
</div>
  <p class="text">
  Соус цезарь, ветчина, пепперони, курица, болгарский перец, оливки, томат, лук, шампиньоны, сыр моцарелла (610гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Пицца Мими (30см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307973">Добавить</a>
  </div>
</div>

<!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/mimi-card.png"alt="">
  <div class="card__label2">700&#8381</div>
</div>
  <p class="text">
  Соус цезарь, ветчина, пепперони, курица, болгарский перец, оливки, томат, лук, шампиньоны, сыр моцарелла (710гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Пицца Мими (35см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307974">Добавить</a>
  </div>
</div>

 <!-- Карточка товара 1 -->
 <div class="block">
    <div class="card-price">
  <img src="./img/piperoni-tomat.png"alt="">
  <div class="card__label2">550&#8381</div>
</div>
  <p class="text">
  Томаты, соус, пепперони, сыр моцарелла, базилик (530гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Пепперони с томатами (30см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307975">Добавить</a>
  </div>
</div>

<!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/piperoni-tomat.png"alt="">
  <div class="card__label2">600&#8381</div>
</div>
  <p class="text">
  Томаты, соус, пепперони, сыр моцарелла, базилик (630гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Пепперони с томатами (35см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307976">Добавить</a>
  </div>
</div>

 <!-- Карточка товара 1 -->
 <div class="block">
    <div class="card-price">
  <img src="./img/ranch.png"alt="">
  <div class="card__label2">500&#8381</div>
</div>
  <p class="text">
  Ранч соус, куриная грудка, сыр моцарелла, томаты (520гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Цыпленок Ранч (30см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307977">Добавить</a>
  </div>
</div>

 <!-- Карточка товара 1 -->
 <div class="block">
    <div class="card-price">
  <img src="./img/ranch.png"alt="">
  <div class="card__label2">550&#8381</div>
</div>
  <p class="text">
  Ранч соус, куриная грудка, сыр моцарелла, томаты (620гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Цыпленок Ранч (35см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307978">Добавить</a>
  </div>
</div>


 <!-- Карточка товара 1 -->
 <div class="block">
    <div class="card-price">
  <img src="./img/kostroma-card.png"alt="">
  <div class="card__label2">500&#8381</div>
</div>
  <p class="text">
  Соус томатный, куриная грудка, сыр моцарелла, соус песто, томаты черри (540гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Кострома (30см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307979">Добавить</a>
  </div>
</div>

 <!-- Карточка товара 1 -->
 <div class="block">
    <div class="card-price">
  <img src="./img/kostroma-card.png"alt="">
  <div class="card__label2">600&#8381</div>
</div>
  <p class="text">
  Соус томатный, куриная грудка, сыр моцарелла, соус песто, томаты черри (640гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Кострома (35см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307980">Добавить</a>
  </div>
</div>


 <!-- Карточка товара 1 -->
 <div class="block">
    <div class="card-price">
  <img src="./img/mexicana-card.png"alt="">
  <div class="card__label2">500&#8381</div>
</div>
  <p class="text">
  Соус, куриная грудка, болгарский перец, томат, красный лук, халапеньо, острый соус, сыр моцарелла (465гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Мексиканская (30см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307981">Добавить</a>
  </div>
</div>


 <!-- Карточка товара 1 -->
 <div class="block">
    <div class="card-price">
  <img src="./img/mexicana-card.png"alt="">
  <div class="card__label2">550&#8381</div>
</div>
  <p class="text">
  Соус, куриная грудка, болгарский перец, томат, красный лук, халапеньо, острый соус, сыр моцарелла (565гр.) </p>
  <h2 class="text2"><span style="font-weight:bold">Мексиканская (35см) </span></h2>
  
  
  <div class="btn-cont">
  <a class="btn-ens-action" data-rel="4e44247d307982">Добавить</a>
  </div>
</div>

    
                  



























      



















             
    </div>
        </section>
        <br> 
<br> 

    </main>

    <script src="js/script.js"></script>
    <script defer src="https://lk.easynetshop.ru/frontend/v5/ens-4e44247d.js"></script>
    <style>.powered {display:none}</style>
   
</body>

</html>