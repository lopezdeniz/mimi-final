<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="utf-8">
    <title>Доставка суши, роллов и пиццы Кострома - МиМи суши</title>
   
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style2.css">
    <link rel="stylesheet" href="css/media-config.css">
    <link rel="stylesheet" href="css/font-awesome-4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="jquery-3.6.3.min.js"></script>
    <meta charset="UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Бесплатная доставка суши, роллов и пиццы на дом — вкусно, дешево, быстро, заказ онлайн или по телефону. Мы готовим только из свежих продуктов высокого качества.">
    <meta name="keywords" content="доставка пиццы, заказ пиццы, пицца круглосуточно, суши, роллы, доставка суши, заказ суши, суши круглосуточно, доставка роллов, заказ роллов, роллы круглосуточно">
    
</head>




<body>
    


<script src="https://tp.media/content?trs=216425&shmarker=418100.418100&combine_promos=101_7873&show_hotels=true&locale=ru&currency=rub&searchUrl=www.aviasales.ru%2Fsearch&color_button=%2332a8dd&color_icons=%2332a8dd&dark=%23262626&light=%23FFFFFF&secondary=%23FFFFFF&special=%23C4C4C4&color_focused=%2332a8dd&border_radius=0&no_labels=&plain=false&promo_id=7879&campaign_id=100" charset="utf-8"></script>



<script src="https://c45.travelpayouts.com/content?trs=216425&shmarker=418100.ID%20418100&tab1=0&tab2=1&tabDef=0&powered_by=true&color_scheme=basic_white&hide_logo=false&hide_logo_tab=false&promo_id=1809" charset="utf-8" async="true"></script>


<script src="https://tp.media/content?trs=216425&shmarker=418100.418100&locale=ru&plain=true&border_radius=5&color_background=%23ffffff&color_border=%23358ed0&color_button=%23fbb718&color_icons=%23fbb718&color_button_text=%23ffffff&promo_id=4072&campaign_id=135" charset="utf-8"></script>



</body>

</html>