<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="utf-8">
    <title>Доставка суши, роллов и пиццы Кострома - МиМи суши</title>
    <link href="https://lk.easynetshop.ru/frontend/v5/ens-4e44247d.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/site.webmanifest">
    <link rel="stylesheet" href="css/style2.css">
    <link rel="stylesheet" href="css/style3.css">
    <link rel="stylesheet" href="css/media-config.css">
    <script type="text/javascript" src="jquery-3.6.3.min.js"></script>
    <link rel="stylesheet" href="css/font-awesome-4.7.0/css/font-awesome.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Бесплатная доставка суши, роллов и пиццы на дом — вкусно, дешево, быстро, заказ онлайн или по телефону. Мы готовим только из свежих продуктов высокого качества.">
    <meta name="keywords" content="доставка пиццы, заказ пиццы, пицца круглосуточно, суши, роллы, доставка суши, заказ суши, суши круглосуточно, доставка роллов, заказ роллов, роллы круглосуточно">
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();
   for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
   k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(92807488, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true,
        ecommerce:"dataLayer"
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/92807488" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</head>

<body>
<?php
include('nav.php')
?>

        <section class="fon-back">
        <div class="mytext-centr"><h2 class="menu-centr">АКЦИИ</h2></div>






        <div class="cards2" >


      

<!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/nej-card.png"alt="">
  <div class="card__label2">1200&#8381</div>
</div>
  <p class="text">Заказ на сумму от 1200р Пицца В Подарок!</p>
  <h2 class="text2"><span style="font-weight:bold">Пицца в Подарок! </span></h2>
  
  
  <div class="btn-cont"> 
  <a href=index.php class="roll-add2"><button class="card__add">Выбрать</button></a>
  </div>
</div>



<!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/card-zap-s-krivetkoi.jpg"alt="">
  <div class="card__label2">1000&#8381</div>
</div>
  <p class="text">Заказ на сумму от 1000р Запеченный Ролл В Подарок!</p>
  <h2 class="text2"><span style="font-weight:bold">Запеченный Ролл в Подарок! </span></h2>
  
  
  <div class="btn-cont"> 
  <a href=index.php class="roll-add2"><button class="card__add">Выбрать</button></a>
  </div>
</div>




<!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/tempura-kali-card.png"alt="">
  <div class="card__label2">700&#8381</div>
</div>
  <p class="text">Заказ на сумму от 700р Темпура Ролл В Подарок!</p>
  <h2 class="text2"><span style="font-weight:bold">Темпура Ролл в Подарок! </span></h2>
  
  
  <div class="btn-cont"> 
  <a href=index.php class="roll-add2"><button class="card__add">Выбрать</button></a>
  </div>
</div>


<!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/margarita.png"alt="">
  <div class="card__label2">Акция</div>
</div>
  <p class="text">При Покупке двух пицц, третья + морс 0.5 В Подарок!</p>
  <h2 class="text2"><span style="font-weight:bold">Пицца и Морс в Подарок! </span></h2>
  
  
  <div class="btn-cont"> 
  <a href=pizza.php class="roll-add2"><button class="card__add">Выбрать</button></a>
  </div>
</div>


<!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/mors-klukva-card.png"alt="">
  <div class="card__label2">Акция</div>
</div>
  <p class="text">При Покупке Пиццы, морс 0.5 В Подарок!</p>
  <h2 class="text2"><span style="font-weight:bold">Морс в Подарок! </span></h2>
  
  
  <div class="btn-cont"> 
  <a href=pizza.php class="roll-add2"><button class="card__add">Выбрать</button></a>
  </div>
</div>



<!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/fil-card.png"alt="">
  <div class="card__label2">Акция</div>
</div>
  <p class="text">При Покупке Трех Роллов, Филадельфия В Подарок!</p>
  <h2 class="text2"><span style="font-weight:bold">Филадельфия в Подарок! </span></h2>
  
  
  <div class="btn-cont"> 
  <a href=rolls.php class="roll-add2"><button class="card__add">Выбрать</button></a>
  </div>
</div>




<!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/kavkazskaya-card.png"alt="">
  <div class="card__label2">Акция</div>
</div>
  <p class="text">При Покупке Двух Шаурмы, Третья В Подарок!</p>
  <h2 class="text2"><span style="font-weight:bold">ШАУРМА в Подарок! </span></h2>
  
  
  <div class="btn-cont"> 
  <a href=fastfood.php class="roll-add2"><button class="card__add">Выбрать</button></a>
  </div>
</div>



<!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/fil-crevet-card.png"alt="">
  <div class="card__label2">Акция</div>
</div>
  <p class="text">При Покупке Двух Любых Сетов, ФИЛАДЕЛЬФИЯ с КРИВЕТКОЙ В Подарок!</p>
  <h2 class="text2"><span style="font-weight:bold">ФИЛАДЕЛЬФИЯ с КРИВЕТКОЙ в Подарок! </span></h2>
  
  
  <div class="btn-cont"> 
  <a href=sets.php class="roll-add2"><button class="card__add">Выбрать</button></a>
  </div>
</div>


<!-- Карточка товара 1 -->
<div class="block">
    <div class="card-price">
  <img src="./img/cezar-cur.png"alt="">
  <div class="card__label2">Акция</div>
</div>
  <p class="text">При Покупке  Сета Гункан, Салат ЦЕЗАРЬ В Подарок!</p>
  <h2 class="text2"><span style="font-weight:bold">Салат ЦЕЗАРЬ в Подарок! </span></h2>
  
  
  <div class="btn-cont"> 
  <a href=sets.php class="roll-add2"><button class="card__add">Выбрать</button></a>
  </div>
</div>



      



















             
    </div>
        </section>
        
        <br> 
<br> 
    </main>

    <script src="js/script.js"></script>
    <script defer src="https://lk.easynetshop.ru/frontend/v5/ens-4e44247d.js"></script>
    <style>.powered {display:none}</style>
    
   
</body>

</html>